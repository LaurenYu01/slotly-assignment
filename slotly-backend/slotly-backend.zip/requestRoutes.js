// routes/requestRoutes.js
const express = require('express');
const router = express.Router();
const authenticateToken = require('../middleware/auth');
const pool = require('../config/db');

// ✅ 发送预约请求
router.post('/requests', authenticateToken, async (req, res) => {
  const { email, time, msg } = req.body;
  const user_id = req.user.id;

  if (!email || !time || !msg) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  try {
    const result = await pool.query(
      'INSERT INTO requests (user_id, email, time, msg) VALUES ($1, $2, $3, $4) RETURNING *',
      [user_id, email, time, msg]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error('❌ Failed to create request:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ✅ 获取当前用户的预约请求
router.get('/requests', authenticateToken, async (req, res) => {
  const user_id = req.user.id;

  try {
    const result = await pool.query(
      'SELECT id, email, time, msg FROM requests WHERE user_id = $1 ORDER BY id DESC',
      [user_id]
    );
    res.json(result.rows);
  } catch (err) {
    console.error('❌ Failed to fetch requests:', err);
    res.status(500).json({ error: 'Failed to fetch requests' });
  }
});

module.exports = router;
